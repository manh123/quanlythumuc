

 
<!DOCTYPE html>
<html>
 <head>
  <title>chart with PHP & Mysql | lisenme.com </title>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
  
 </head>
 <body >
 <h2 > data show</h2
 
 <?php
$connect = mysqli_connect("localhost", "root", "123456", "khoaluan");// dang nhap vao data base 

$query1 = "SELECT * FROM temperature WHERE  datetime  ORDER BY datetime DESC limit 5   "; //đieu kien lay du lieu theo datatime, lay theo thoi gian som nhat,lay 5 dong

$result1 = mysqli_query($connect, $query1);// doc data theo dieu kien cua query1

$query = "SELECT * FROM temperature "; // lay toan bo data cua ban temperature
$result = mysqli_query($connect, $query);//  doc data theo dieu kien cua query
$chart_data = '';

//$query = mysql_query($sql);
//$num = mysqli_num_rows($result);
//if ($num > 0)
	
while($row = mysqli_fetch_array($result1)) //dieu kien xuat theo query1
{
	
 printf ("datetime: %s, &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp Temp: %s,&nbsp;&nbsp; &nbsp;&nbsp;  Hum: %s,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp 	soil: %s<br>",$row[4],$row[1], $row[2], $row[3]);  //code hien thi data thuong   </div>
}


while($row = mysqli_fetch_array($result)) //dieu kien xuat theo query
{
	
	//code hien thi data thanh bieu do  
 $chart_data .= "{ datetime:'".$row["datetime"]."', temp:".$row["temp"].", hum:".$row["hum"].", Soil:".$row["Soil"]."}, ";

}
$chart_data = substr($chart_data, 0, -2);

?>
 
 
 
 
 
 
 
  
  <div class="container" style="width:1350px;">
   <h2 align="center">Morris.js chart with PHP & Mysql</h2>
   <h3 align="center">Last 10 Years Profit, Purchase and Sale Data</h3>   
   <br /><br />
   <div  align=left id="chart" ></div>
  </div>
 </body>
</html>
 
<script >

// thong tin bieu do
Morris.Bar({
 element : 'chart',
 data:[<?php echo $chart_data; ?>],
 xkey:'datetime',
 ykeys:['temp', 'hum', 'Soil'],
 labels:['temp', 'hum', 'Soil' ],
 hideHover:'100px',
 stacked:true
});
</script>